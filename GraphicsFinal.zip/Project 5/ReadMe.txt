Robert Bethune
Jacob Ellenberg
We also worked with Evan Schipellite

Exercise 5 Endless Terrain
This exercise helped us learn to use an endless terrain and methods to save data.

Use the mouse to rotate,WASD to move the camera. Use 1 to toggle wireframe. Use T to toggle texture. Use the N key to toggle normal maps on and off.